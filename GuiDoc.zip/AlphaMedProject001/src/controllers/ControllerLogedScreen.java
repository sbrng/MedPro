import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TitledPane;

public class PleaseProvideControllerClassName {

    @FXML
    private Label docUsername;

    @FXML
    private Label docName;

    @FXML
    private Label docSpeciality;

    @FXML
    private Label docWorkplace;

    @FXML
    private TitledPane appointmentTable;

    @FXML
    private Button botaoLogOut;

    @FXML
    void goToLogOout(ActionEvent event) {

    }

}
